from flask import Flask, render_template, request
import joblib
from pathlib import Path
import re
import datetime
import pandas as pd

app = Flask(__name__)

# Define the base path to the model directory
base_path = Path(__file__).parent

# Load the model and encoders
model_path = base_path / 'model' / 'airline_price_model.pkl'
model = joblib.load(model_path)

encoders = {}
for col in ['Airline', 'Source', 'Destination', 'Number of Stops', 'Class']:
    encoder_path = base_path / 'model' / f'{col}_encoder.pkl'
    encoders[col] = joblib.load(encoder_path)

# Function to convert duration strings to minutes
def duration_to_minutes(duration):
    match = re.match(r'((?P<hours>\d+)h )?(?P<minutes>\d+)m', duration)
    if not match:
        return 0
    parts = match.groupdict()
    return int(parts['hours'] or 0) * 60 + int(parts['minutes'] or 0)

@app.route('/', methods=['GET', 'POST'])
def index():
    flights = None
    if request.method == 'POST':
        source = request.form['source']
        destination = request.form['destination']
        number_of_stops = request.form['number_of_stops']
        flight_class = request.form['flight_class']
        departure_time = request.form['departure_time']
        arrival_time = request.form['arrival_time']
        flight_date = request.form['flight_date']
        days_left = int(request.form['days_left'])
        total_stopover_time = request.form['total_stopover_time']
        min_price = float(request.form['min_price'])
        max_price = float(request.form['max_price'])

        departure_time = datetime.datetime.strptime(departure_time, '%H:%M').time()
        arrival_time = datetime.datetime.strptime(arrival_time, '%H:%M').time()
        flight_date = datetime.datetime.strptime(flight_date, '%Y-%m-%d').date()

        # Simulate flight data
        flight_data = {
            'Airline': [],
            'Source': [],
            'Destination': [],
            'Number of Stops': [],
            'Class': [],
            'Price': []
        }

        for airline in encoders['Airline'].classes_:
            encoded_inputs = [
                encoders['Airline'].transform([airline])[0],
                encoders['Source'].transform([source])[0],
                encoders['Destination'].transform([destination])[0],
                encoders['Number of Stops'].transform([number_of_stops])[0],
                encoders['Class'].transform([flight_class])[0],
                departure_time.hour,
                departure_time.minute,
                arrival_time.hour,
                arrival_time.minute,
                flight_date.day,
                flight_date.month,
                flight_date.year,
                duration_to_minutes(total_stopover_time),
                days_left
            ]

            price = model.predict([encoded_inputs])[0]

            if min_price <= price <= max_price:
                flight_data['Airline'].append(airline)
                flight_data['Source'].append(source)
                flight_data['Destination'].append(destination)
                flight_data['Number of Stops'].append(number_of_stops)
                flight_data['Class'].append(flight_class)
                flight_data['Price'].append(price)

        flights = pd.DataFrame(flight_data)

    return render_template('flights.html', flights=flights, encoders=encoders)

if __name__ == '__main__':
    app.run(debug=True)
